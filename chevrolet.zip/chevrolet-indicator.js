$("document").ready(function(){
  $(window).scroll(function(){
    var current = ($(window).scrollTop() / ($(document).outerHeight() - $(window).height())) * 100;
    $(".indicator").width(current + "%")
  })  
})