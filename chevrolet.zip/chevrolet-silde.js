$("document").ready(function(){
    var a = 0,
        leng = $(".visual ul li").length - 1,
        time = false;
        auto_play = setInterval(function(){a++; if(a > leng) a = 0; $(".visual ul").stop().animate({left: "-100" * a + "%"}, 1000)}, 3000)
        $(".visual a").click(function(e){
            e.preventDefault();
            var i = $(".visual a").index(this);
            if(time == true){return;}
            setTimeout(function(){time = false;}, 1000)
            time = true;
            if(i == 0){a--; if(a < 0) a = leng;}else{a++; if(a > leng) a = 0;}
            console.log(a)
            $(".visual ul").stop().animate({left: "-100" * a + "%"}, 1000)
        }) 
    $(".visual ul").hover(function(){
        clearInterval(auto_play)
    }, function(){
        clearInterval(auto_play);
        auto_play = setInterval(function(){a++; if(a > leng) a = 0; $(".visual ul").stop().animate({left: "-100" * a + "%"}, 1000)}, 3000)
    })
}) 